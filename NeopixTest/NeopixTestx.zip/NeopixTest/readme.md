# MVVM Sample App
The main purpose of this app is to show MVVM sample implementation using the new Google Architectural
components LiveData and ViewModel.