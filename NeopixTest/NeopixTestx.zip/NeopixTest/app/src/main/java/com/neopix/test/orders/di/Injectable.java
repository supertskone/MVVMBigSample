package com.neopix.test.orders.di;

/**
 * Marker interface for fragments.
 */
public interface Injectable {
}
