package com.neopix.test.orders.service.model;

public class StatusType {
    public static final String PARTIALLYACCEPTED = "PARTIALLY ACCEPTED";
    public static final String ACCEPTED = "ACCEPTED";
    public static final String PENDING = "PENDING";
}
