package com.neopix.test.orders.service.model;

import com.google.gson.annotations.SerializedName;

public class OrderDetails {
  @SerializedName("data")
  public Order data;
}
