package com.neopix.test.orders.service.model;

public class ItemType {
  public static final int Post = 1;
  public static final int Header = 2;
}
